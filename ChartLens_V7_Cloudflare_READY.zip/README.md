# ChartLens V7 — Cloudflare Pages

This build is prepared for Cloudflare Pages with Pages Functions.

## Cloudflare setup
1. Deploy this project to Cloudflare Pages.
2. In the project settings, add an environment variable named `HF_TOKEN` under Functions/Workers environment variables.
3. Set it to your Hugging Face token. Keep it secret; do not put it in `public/index.html`.
4. Redeploy after saving the variable.

The frontend calls `/api/analyze`, which is handled by `functions/api/analyze.js`.
