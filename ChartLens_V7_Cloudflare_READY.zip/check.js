
const imageInput=document.getElementById('image');
const preview=document.getElementById('preview');
const status=document.getElementById('status');
const results=document.getElementById('results');
const button=document.getElementById('analyze');

imageInput.addEventListener('change',()=>{
  const f=imageInput.files[0];
  if(!f){preview.style.display='none';return}
  preview.src=URL.createObjectURL(f); preview.style.display='block';
  status.className='status'; status.textContent='Chart loaded. Ready to analyze.';
});

function esc(s){return String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
function section(title,value){return `<div class="section"><h3>${esc(title)}</h3><p>${esc(value||'Not available from the image.')}</p></div>`}

function render(r){
  const conf=(r.confidence||'medium').toLowerCase();
  const cls=conf==='high'?'high':conf==='low'?'low':'medium';
  const label=conf==='high'?'🟢 High confidence':conf==='low'?'🔴 Low confidence':'🟡 Moderate confidence';
  const score=r.confidence_score!=null?Number(r.confidence_score):null;
  results.style.display='block';
  const row=(icon,title,value,scoreValue)=>`<div class="analysisRow"><div class="analysisIcon">${icon}</div><div><div class="analysisLabel">${esc(title)}</div><div class="analysisText">${esc(value||'Not available from the image.')}</div></div><div class="analysisScore">${scoreValue!=null?`Confidence<span>${esc(scoreValue)}%</span>`:'Evidence<span>—</span>'}</div></div>`;
  results.innerHTML=
    `<div class="resultsHead"><div class="resultsTitle">AI Chart Analysis</div><div class="confidence ${cls}">${label}${score!=null?' — '+esc(score)+'%':''}</div></div>`+
    `<div class="section"><h3>Overall assessment</h3><p>${esc(r.overall_assessment||'Not available from the image.')}</p></div>`+
    `<div class="grid" style="margin-top:14px">`+
      `<div class="metric"><b>Asset</b>${esc(r.asset)}</div><div class="metric"><b>Timeframe</b>${esc(r.timeframe)}</div><div class="metric"><b>Bias</b>${esc(r.bias)}</div><div class="metric"><b>Image quality</b>${esc(r.image_quality)}</div>`+
    `</div>`+
    `<div class="section"><h3>Detected features</h3>`+
      row('📊','Market Structure',r.market_structure)+
      row('🎯','Key Levels',r.key_levels)+
      row('◇','Chart Patterns',r.chart_patterns,r.pattern_confidence)+
      row('⚡','Momentum',r.momentum_volatility)+
      row('🛡','Supply & Demand',r.supply_demand)+
    `</div>`+
    section('Trend',r.trend)+section('Support / resistance',r.support_resistance)+section('Liquidity / sweeps',r.liquidity)+section('BOS / CHoCH',r.bos_choch)+section('Candlestick behaviour',r.candlesticks)+section('Moving averages',r.moving_averages)+section('Volume',r.volume)+section('Scenario / confirmation',r.scenario)+section('Invalidation / caution',r.invalidation)+
    `<div class="section"><h3>Overall AI confidence</h3><div class="overall"><div class="scoreRing">${score!=null?esc(score)+'%':'—'}<small>VISIBLE EVIDENCE</small></div><div><strong style="font-size:20px">${label}</strong><p style="margin-top:7px">Confidence reflects the model's confidence in identifying visible chart features. It is not a probability of trade success.</p></div></div></div>`+
    `<div class="section"><h3>Educational note</h3><p>Analysis is limited to information readable in the uploaded chart. Missing, cropped or ambiguous information is reported as unavailable rather than guessed.</p></div>`;
}

button.addEventListener('click',async()=>{
  const f=imageInput.files[0];
  if(!f){status.className='status error';status.textContent='Please upload a chart image first.';return}
  button.disabled=true; results.style.display='none';
  status.className='status'; status.textContent='Analyzing chart…';
  try{
    const b64=await new Promise((resolve,reject)=>{
      const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=reject;r.readAsDataURL(f)
    });
    const focus=[...document.querySelectorAll('#focuses input:checked')].map(x=>x.value);
    const res=await fetch('/.netlify/functions/analyze',{
      method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({image:b64,asset:document.getElementById('asset').value,timeframe:document.getElementById('timeframe').value,focus})
    });
    const text=await res.text();
    let data;
    try{data=JSON.parse(text)}catch(e){throw new Error('The analysis service returned an invalid response. Check the Netlify function and HF_TOKEN configuration.')}
    if(!res.ok) throw new Error(data.error||'Analysis request failed.');
    render(data); status.className='status'; status.textContent='Analysis complete.';
  }catch(e){status.className='status error';status.textContent=e.message||'Analysis failed.'}
  finally{button.disabled=false}
});
